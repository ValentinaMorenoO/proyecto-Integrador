
import processing.core.PApplet;

public class Ejecutable extends PApplet {

	public static void main(String[] args) {
       PApplet.main("Ejecutable");
	}

	private Logica log;

	@Override
	public void settings() {
		size(1200, 500);
	}

	@Override
	public void setup() {
		noStroke();
		textSize(20);
		log = new Logica(this);
	}

	// @Override
	 public void keyPressed() {
	 log.press();
	 }

	@Override
	public void draw() {
		background(0);
		log.pintar();
	}
}
