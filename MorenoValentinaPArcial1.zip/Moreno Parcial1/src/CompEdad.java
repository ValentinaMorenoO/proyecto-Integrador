import java.util.Comparator;

public class CompEdad implements Comparator<Usuario>{

	@Override
	public int compare(Usuario o1, Usuario o2) {
		// TODO Auto-generated method stub
		return (int) (o1.getEdad()-(o2.getEdad()));
	}

}
