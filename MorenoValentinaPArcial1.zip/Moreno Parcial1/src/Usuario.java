import processing.core.PApplet;

public class Usuario implements Comparable<Usuario>{
	
	private PApplet app;

	private String nombre, apellido;
	float cedula, edad,peso;

	private int  r, g, b, x, y;
	
//	public Usuario(String nombre, String apellido, int cedula, int edad, int peso, int r, int g, int b) {
//		this.nombre= nombre;
//		this.apellido=apellido;
//		this.cedula=cedula;
//		this.edad=edad;
//		this.peso=peso;
//		this.r=r;
//		this.g=g;
//		this.b=b;
//		
//	}
	
	public Usuario(PApplet app, String nombre, String apellido, float cedula, float edad, float peso , int r, int g, int b) {
		this.app = app;
		this.nombre= nombre;
		this.apellido=apellido;
		this.cedula=cedula;
		this.edad=edad;
		this.peso=peso;
		this.r=r;
		this.g=g;
		this.b=b;
		
	}
	
	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	public void pintar(int x, int y){
		this.x=x;
		this.y=y;
		app.fill(r,g,b);
		app.text(nombre + " " + apellido+"     "+cedula+"      "+ edad+ "     " +peso, x, y);
		app.noFill();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	@Override
	public int compareTo(Usuario o) {
		// TODO Auto-generated method stub
		return getNombre().compareTo(o.getNombre());
	}

	public float getEdad() {
		return edad;
	}

	public void setEdad(float edad) {
		this.edad = edad;
	}
	

}
