import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

import processing.core.PApplet;

public class Logica {
	
	private PApplet app;
	private LinkedList<Usuario> u;
	private LinkedList <Usuario> d;
	TreeSet<Usuario> peso;
	
	Logica(PApplet app) {
		this.app=app;
		u = new LinkedList<>();
		txt();
		
		peso= new TreeSet<>(new CompPeso());
	}
	
	public void txt() {
		String[] texto= app.loadStrings("../data/usuario.txt");
		String[] datos= app.loadStrings("../data/datos.txt");
		String[] tonos= app.loadStrings("../data/tonos.txt");
		
		
		for (int i = 1; i < texto.length; i++) {
			String[] nombreyapellido= texto[i].split(":");
			String[] daticos= datos[i].split("/");
			String[] colores= tonos[i].split("/");

			float[] daticosInt= new float[datos.length];
			for (int j = 0; j < daticos.length; j++) {
			daticosInt[j]= Float.parseFloat(daticos[j]);
			}
			int[] coloresInt= new int[colores.length];
			for (int j = 0; j < colores.length; j++) {
			coloresInt[j]=Integer.parseInt(colores[j]);
			}
			
			
		    u.add(new Usuario(app, nombreyapellido[0], nombreyapellido[1], daticosInt[0],daticosInt[1],daticosInt[2],coloresInt[0],coloresInt[1],coloresInt[2]));
		    
		}
		
		
		
		
	}
	
	public void pintar() {
		Iterator<Usuario> it = u.iterator();
		int i = 0;
		while (it.hasNext()) {
			Usuario temp = it.next();
			temp.pintar(30, 30+(i*30));
			i++;
		}
		
		Iterator<Usuario> h = peso.iterator();
		int o = 0;
		while (h.hasNext()) {
			Usuario ba= h.next();
			ba.pintar(30, 30+(o*30));
			o++;
		}
		
		
		
	}
	public void press() {
		// TODO Auto-generated method stub
		if(app.key=='1'){
		Collections.sort(u);
		}
		if(app.key=='2'){
			Collections.sort(u, new comparatorsito());
			}
		
		if(app.key=='3'){
			Collections.sort(u, new CompPeso());
				
//				edad.addAll(u);
//				u.clear();
				}
		if(app.key=='4'){
			Collections.sort(u, new CompPeso());
				
			peso.addAll(u);
			u.clear();
				}
		if(app.key=='6'){
			Collections.shuffle(u);
			
			}
		
		
		
		
		
		
	}

}
