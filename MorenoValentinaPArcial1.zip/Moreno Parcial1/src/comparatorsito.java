import java.util.Comparator;

public class comparatorsito implements Comparator<Usuario>{

	@Override
	public int compare(Usuario o1, Usuario o2) {
		// TODO Auto-generated method stub
		return o1.getApellido().compareTo(o2.getApellido());
	}

}
