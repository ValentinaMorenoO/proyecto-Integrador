import java.util.Comparator;

public class CompPesoDesc implements Comparator<Usuario>{



	@Override
	public int compare(Usuario o1, Usuario o2) {
		return (int) (o2.getPeso()-o1.getPeso());
	}
}
